package com.ticketbooking.login;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ticketbooking.adminview.AdminView;
import com.ticketbooking.userview.UserView;

public class LoginView implements LoginViewCallBack {

    private LoginControllerCallBack controller;
    private Scanner scanner = new Scanner(System.in);
    private String name;

    public LoginView() {
        controller = new LoginController(this);
    }

    public static void main(String[] args) {
        new LoginView().welcome();
    }

    public void welcome() {
        System.out.println("\t\t-->WELCOME TO IRCTC <--");
        login();
    }

    public void login() {
        System.out.println("1.Admin Login\n2.User Login\n3.SignUp\n4.Exit");
        String choice = scanner.nextLine();
        switch (choice) {
            case "1":
                adminLogin();
                break;
            case "2":
                userLogin();
                break;
            case "3":
                signup();
                break;
            case "4":
                exit();
            default:
                System.out.println("Enter a valid number");
                login();
        }
    }

    public void signup() {
        String name = validateName("Enter your full name :");


        String address = validateAddress();

        long mobileNumber = validateMobileNumber();

        String mailID = validateEmail("Enter your mail ID:");

        String password = validatePassword();

        controller.createAccount(name, password, address, mobileNumber, mailID);
    }

    private String validateName(String message) {
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine().trim();

            if (input.matches("^[A-Za-z ]+$")) {
                return input.toUpperCase();
            } else {
                System.out.println("Invalid name format. Please enter your full name .");
            }
        }
    }


    private String validateAddress() {
        while (true) {
            System.out.println("Enter your address:");
            String input = scanner.nextLine().trim();

            if (!input.isEmpty() && input.length() >= 20) {
                return input;
            } else {
                System.out.println("Invalid address. Please enter a valid address with at least 20 characters.");
            }
        }
    }



    private long validateMobileNumber() {
        String MOBILE_NUMBER_PATTERN = "^(\\+\\d{1,3}[- ]?)?\\d{10,13}$";

        while (true) {
            System.out.println("Enter your mobile number:");
            String input = scanner.nextLine();

            Pattern pattern = Pattern.compile(MOBILE_NUMBER_PATTERN);
            Matcher matcher = pattern.matcher(input);

            if (matcher.matches()) {
                return Long.parseLong(input);
            } else {
                System.out.println("Invalid mobile number format. Please enter a valid mobile number .");
            }
        }
    }



    private String validateEmail(String message) {
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine();

            if (input.indexOf('@') == input.lastIndexOf('@') &&
                    input.endsWith(".com") && input.indexOf(".com") == input.lastIndexOf(".com"))

               {
                return input;
            } else {
                System.out.println("Invalid email format. Please enter a valid email ID .");
            }
        }
    }



    private String validatePassword() {
        String PASSWORD_PATTERN = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";

        while (true) {
            System.out.println("Enter your password (at least 8 characters with at least 1 lowercase, 1 uppercase, 1 digit, and 1 special symbol):");
            String input = scanner.nextLine();

            if (Pattern.matches(PASSWORD_PATTERN, input)) {
                return input;
            } else {
                System.out.println("Invalid password format. Password must meet the criteria.");
            }
        }
    }

    public void userLogin() {
        System.out.println("Enter your user name");
        name = scanner.nextLine();
        System.out.println("Enter your password");
        String password = scanner.nextLine();
        controller.validLogin(name, password);
    }

    public void adminLogin() {
        System.out.println("Enter Your user name");
        String userName = scanner.nextLine();
        System.out.println("Enter your password");
        String password = scanner.nextLine();
        controller.validAdmin(userName, password);
    }

    public void exit() {
        System.out.println("\t\t\t\t\tTHANK YOU FOR VISITING OUR WEB PAGE:)");
        System.exit(0);
    }

    @Override
    public void accountCreated(String string) {
        System.out.println(string);
        new UserView().userView(name);
    }

    @Override
    public void validAdmin(String string) {
        System.out.println(string);
        new AdminView().adminView();
    }

    @Override
    public void invalidAdmin(String string) {
        System.out.println(string);
        login();
    }

    @Override
    public void validUser(String string) {
        System.out.println(string);
        new UserView().userView(name);
    }

    @Override
    public void invalidUser(String string) {
        System.out.println(string);
        login();
    }

}