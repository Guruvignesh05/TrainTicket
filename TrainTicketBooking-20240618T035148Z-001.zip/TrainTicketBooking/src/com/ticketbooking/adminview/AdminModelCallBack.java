package com.ticketbooking.adminview;

public interface AdminModelCallBack {

    void bookings();

    void trainDetails();

}