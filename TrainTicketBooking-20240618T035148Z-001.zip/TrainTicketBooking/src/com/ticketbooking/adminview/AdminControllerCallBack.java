package com.ticketbooking.adminview;

public interface AdminControllerCallBack {

    void bookings();

    void trainDetails();

}