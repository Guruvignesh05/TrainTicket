package com.ticketbooking.repository;

import java.io.File;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ticketbooking.dto.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ticketbooking.dto.Admin;
import com.ticketbooking.dto.Amount;
import com.ticketbooking.dto.MyBooking;
import com.ticketbooking.dto.Reservation;
import com.ticketbooking.dto.Tatkal;
import com.ticketbooking.dto.Train;
import com.ticketbooking.dto.TrainSeats;

public class Repository {

    private List<Admin> adminDetails = new ArrayList<>();
    private Data data;
    private TrainData trainData;
    private Reservation reservation = new Reservation();
    private Tatkal tatkal = new Tatkal();
    private HashMap<String, User> users = new HashMap<>();
    private HashMap<Integer, Train> available = new HashMap<>();

    private List<String> CoimbatoreToMannargudi = new ArrayList<>();
    private List<String> MannargudiToCoimbatore = new ArrayList<>();
    private List<String> ChennaiEgmoreToSengottai = new ArrayList<>();
    private List<String> SengottaiToChennaiEgmore = new ArrayList<>();

    private static Repository repository;

    private Repository() {
        this.readFile();
        this.readTrainFile();
    }

    public void exit() {
        this.writeFile();
        this.writeTrainFile();
    }

    public static Repository getInstance() {
        if (repository == null) {
            repository = new Repository();
            repository.adminInfo();
            repository.exit();
        }
        return repository;
    }

    private void writeFile() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File("src//com//ticketbooking//repository//UserDetails.json").getAbsoluteFile(),
                    data);
        } catch (IOException e) {
            System.out.println("Cannot write file");
        }
    }

    private void readFile() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            data = (Data) mapper.readValue(
                    new File("src//com//ticketbooking//repository//UserDetails.json").getAbsoluteFile(), Data.class);
            for (User user : data.getUsers()) {
                users.put(user.getName(), user);
            }
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Cannot read file");
        }
    }

    private void writeTrainFile() {
        ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.writeValue(new File("src//com//ticketbooking//repository//TrainData.json").getAbsoluteFile(),
                    trainData);
        } catch (IOException e) {
            System.out.println("Cannot write train file");
        }
    }

    private void readTrainFile() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            trainData = (TrainData) mapper.readValue(
                    new File("src//com//ticketbooking//repository//TrainData.json").getAbsoluteFile(), TrainData.class);
            for (Train train : trainData.getTrain()) {
                available.put(train.getId(), train);
            }
        } catch (Exception e) {
            System.out.println("Cannot read train file");
        }
    }

    private void adminInfo() {
        adminDetails.add(new Admin("Guru", "0000"));
        adminDetails.add(new Admin("Admin", "0000"));
        trainInfo();
    }

    private void trainInfo() {

        CoimbatoreToMannargudi();
        MannargudiToCoimbatore();
        ChennaiEgmoreToSengottai();
        SengottaiToChennaiEgmore();

        trainData();
    }

    private void trainData() {

        TrainSeats reserve = new TrainSeats(5, 14, 23, 78, 30);
        reservation.getReservation().add(reserve);

        Amount amount = new Amount(1500, 900, 650, 320, 200);
        reservation.getAmount().add(amount);

        TrainSeats tatkalSeat = new TrainSeats(2, 8, 10, 15, 15);
        Amount amount2 = new Amount(2000, 1200, 900, 500, 300);

        tatkal.getTatkal().add(tatkalSeat);
        tatkal.getAmount().add(amount2);
    }

    public Admin validAdmin(String userName, String password) {
        for (Admin admin : adminDetails) {
            if (admin.getUserName().equals(userName) && admin.getPassword().equals(password))
                return admin;
        }
        return null;
    }

    public User validUser(String name, String password) {
        for (User user : data.getUsers()) {
            if (user.getName().equalsIgnoreCase(name) && user.getPassword().equals(password))
                return user;
        }
        return null;
    }

    public void removeUser(String name, String password) {
        for (User user : data.getUsers()) {
            if (user.getName().equalsIgnoreCase(name) && user.getPassword().equals(password)) {
                data.getUsers().remove(user);
                exit();
                break;
            }
        }
    }

    public void createAccount(String name, String password, String address, long mobileNumber, String mailID) {
        String userID = repository.generateUserID(name);
        User user = new User(userID, name, password, address, mobileNumber, mailID);
        data.getUsers().add(user);
        users.put(name, user);
        exit();
    }

    public List<ArrayList<String>> bookings() {
        List<ArrayList<String>> userList = new ArrayList<>();
        for (User user : data.getUsers()) {
            if (user.getBooking() != null) {
                ArrayList<String> userDetails = new ArrayList<>();
                userDetails.add(user.getUserID());
                userDetails.add(user.getName());
                userDetails.add(user.getMailID());
                userDetails.add(user.getAddress());
                userDetails.add(Long.toString(user.getPhoneNumber()));
                userList.add(userDetails);

            }
        }
        return userList;
    }

    private void CoimbatoreToMannargudi() {
        CoimbatoreToMannargudi.add("Coimbatore");
        CoimbatoreToMannargudi.add("Tirupur");
        CoimbatoreToMannargudi.add("Erode");
        CoimbatoreToMannargudi.add("Karur");
        CoimbatoreToMannargudi.add("Trichy");
        CoimbatoreToMannargudi.add("Budalur");
        CoimbatoreToMannargudi.add("Thanjavur");
        CoimbatoreToMannargudi.add("Needamangalam");
        CoimbatoreToMannargudi.add("Mannargudi");
    }



    private void MannargudiToCoimbatore() {
        MannargudiToCoimbatore.add("Mannargudi");
        MannargudiToCoimbatore.add("Needamangalam");
        MannargudiToCoimbatore.add("Thanjavur");
        MannargudiToCoimbatore.add("Budalur");
        MannargudiToCoimbatore.add("Trichy");
        MannargudiToCoimbatore.add("Karur");
        MannargudiToCoimbatore.add("Erode");
        MannargudiToCoimbatore.add("Tirupur");
        MannargudiToCoimbatore.add("Coimbatore");
    }


    private void ChennaiEgmoreToSengottai() {
        ChennaiEgmoreToSengottai.add("Chennai ");
        ChennaiEgmoreToSengottai.add("Tambaram");
        ChennaiEgmoreToSengottai.add("Chengalpattu");
        ChennaiEgmoreToSengottai.add("Villupuram");
        ChennaiEgmoreToSengottai.add("Vriddhachalam");
        ChennaiEgmoreToSengottai.add("Tiruchirappalli");
        ChennaiEgmoreToSengottai.add("Dindigul");
        ChennaiEgmoreToSengottai.add("Madurai");
        ChennaiEgmoreToSengottai.add("Virudhunagar");
        ChennaiEgmoreToSengottai.add("Thiruttangal");
        ChennaiEgmoreToSengottai.add("Sivakasi");
        ChennaiEgmoreToSengottai.add("Srivilliputtur");
        ChennaiEgmoreToSengottai.add("Rajapalayam");
        ChennaiEgmoreToSengottai.add("Pamba kovil Shandy");
        ChennaiEgmoreToSengottai.add("Kadayanallur");
        ChennaiEgmoreToSengottai.add("Tenkasi");
        ChennaiEgmoreToSengottai.add("Sengottai");
    }


    private void SengottaiToChennaiEgmore() {
        SengottaiToChennaiEgmore.add("Sengottai");
        SengottaiToChennaiEgmore.add("Tenkasi");
        SengottaiToChennaiEgmore.add("Kadayanallur");
        SengottaiToChennaiEgmore.add("Pamba kovil Shandy");
        SengottaiToChennaiEgmore.add("Rajapalayam");
        SengottaiToChennaiEgmore.add("Srivilliputtur");
        SengottaiToChennaiEgmore.add("Sivakasi");
        SengottaiToChennaiEgmore.add("Thiruttangal");
        SengottaiToChennaiEgmore.add("Virudhunagar");
        SengottaiToChennaiEgmore.add("Madurai");
        SengottaiToChennaiEgmore.add("Dindigul");
        SengottaiToChennaiEgmore.add("Tiruchirappalli");
        SengottaiToChennaiEgmore.add("Vriddhachalam");
        SengottaiToChennaiEgmore.add("Villupuram");
        SengottaiToChennaiEgmore.add("Chengalpattu");
        SengottaiToChennaiEgmore.add("Tambaram");
        SengottaiToChennaiEgmore.add("Chennai ");
    }


    public List<List<String>> checkTrainAvailability(String from, String to) {
        List<List<String>> trains = new ArrayList<>();
        List<String> array1 = new ArrayList<>();
        array1 = checkMannargudiToCoimbatore(from, to);
        List<String> array2 = new ArrayList<>();
        array2 = checkChennaiEgmoreToSengottai(from, to);

        if (array1.size() != 0)
            trains.add(array1);
        if (array2.size() != 0)
            trains.add(array2);

        return trains;
    }



    private List<String> checkMannargudiToCoimbatore (String from, String to) {
        int start = -1, end = -1, id = 0;
        for (int i = 0; i <CoimbatoreToMannargudi.size(); i++) {
            if (CoimbatoreToMannargudi.get(i).equalsIgnoreCase(from))
                start = i;
            else if (CoimbatoreToMannargudi.get(i).equalsIgnoreCase(to))
                end = i;
        }

        if (start < end)
            id = 1;
        else if (start > end)
            id = 2;
        List<String> array = new ArrayList<>();
        if (id != 0 && start != -1 && end != -1) {
            Train train = available.get(id);
            array.add(Integer.toString(train.getId()));
            array.add(train.getTrainName());
            array.add(train.getTrainNo());
            array.add(train.getFromStation());
            array.add(train.getToStation());
            array.add(train.getTime());
            array.add(Integer.toString(train.getTotalSeats()));
        }
        return array;
    }

    private List<String> checkChennaiEgmoreToSengottai(String from, String to) {
        int start = -1, end = -1, id = 0;
        for (int i = 0; i < SengottaiToChennaiEgmore.size(); i++) {
            if (SengottaiToChennaiEgmore.get(i).equalsIgnoreCase(from))
                start = i;
            else if (SengottaiToChennaiEgmore.get(i).equalsIgnoreCase(to))
                end = i;
        }
        if (start < end)
            id = 4;
        else if (start > end)
            id = 3;

        List<String> array = new ArrayList<>();
        if (id != 0 && start != -1 && end != -1) {
            Train train = available.get(id);
            array.add(Integer.toString(train.getId()));
            array.add(train.getTrainName());
            array.add(train.getTrainNo());
            array.add(train.getFromStation());
            array.add(train.getToStation());
            array.add(train.getTime());
            array.add(Integer.toString(train.getTotalSeats()));
        }
        return array;
    }

    public boolean ticketAvailable(int ticketCount, String seating) {
        switch (seating) {
            case "AC First Class(1A)":
                if (ticketCount <= reservation.getReservation().get(0).getFirstAC())
                    return true;
            case "AC 2Tier(2A)":
                if (ticketCount <= reservation.getReservation().get(0).getSecondAC())
                    return true;
            case "AC 3Tier(3A)":
                if (ticketCount <= reservation.getReservation().get(0).getThirdAC())
                    return true;
            case "Sleeper(SL)":
                if (ticketCount <= reservation.getReservation().get(0).getSleeper())
                    return true;
            case "Second Sitting(2S)":
                if (ticketCount <= reservation.getReservation().get(0).getSecondSitting())
                    return true;
        }
        return false;
    }

    public boolean ticketAvailableTatkal(int ticketCount, String seating) {
        switch (seating) {
            case "AC First Class(1A)":
                if (ticketCount <= tatkal.getTatkal().get(0).getFirstAC())
                    return true;
            case "AC 2Tier(2A)":
                if (ticketCount <= tatkal.getTatkal().get(0).getSecondAC())
                    return true;
            case "AC 3Tier(3A)":
                if (ticketCount <= tatkal.getTatkal().get(0).getThirdAC())
                    return true;
            case "Sleeper(SL)":
                if (ticketCount <= tatkal.getTatkal().get(0).getSleeper())
                    return true;
            case "Second Sitting(2S)":
                if (ticketCount <= tatkal.getTatkal().get(0).getSecondSitting())
                    return true;
        }
        return false;
    }

    public boolean checkOpened() {
        LocalTime localTime = LocalTime.now();
        String time = localTime.toString();
        time = time.substring(0, 2);

        if (Integer.parseInt(time.toString()) >= 11 && Integer.parseInt(time.toString()) <= 15)
            return true;
        else
            return false;
    }

    public int paymentReservation(String seating, int ticketCount) {
        int amount = 0;
        switch (seating) {
            case "AC First Class(1A)":
                amount = ticketCount * reservation.getAmount().get(0).getFirstAC();
                return amount;
            case "AC 2Tier(2A)":
                amount = ticketCount * reservation.getAmount().get(0).getSecondAC();
                return amount;
            case "AC 3Tier(3A)":
                amount = ticketCount * reservation.getAmount().get(0).getThirdAC();
                return amount;
            case "Sleeper(SL)":
                amount = ticketCount * reservation.getAmount().get(0).getSleeper();
                return amount;
            case "Second Sitting(2S)":
                amount = ticketCount * reservation.getAmount().get(0).getSecondSitting();
                return amount;
        }
        return amount;
    }

    public void confirmTicket(String name, String id, String from, String to, int bookedSeats, String statement,
                              int amount, String quota, String trainClass, List<String> seatType, String bookedDate) {

        this.users.get(name.toUpperCase()).getBooking()
                .add(new MyBooking(Integer.parseInt(id), amount, bookedSeats,
                        available.get(Integer.parseInt(id)).getTrainName(), from, to,
                        available.get(Integer.parseInt(id)).getTrainNo(), quota, statement, seatType, bookedDate));

        trainData.getTrain().get(Integer.parseInt(id) - 1)
                .setTrainName(available.get(Integer.parseInt(id)).getTrainName());
        trainData.getTrain().get(Integer.parseInt(id) - 1)
                .setFromStation(available.get(Integer.parseInt(id)).getFromStation());
        trainData.getTrain().get(Integer.parseInt(id) - 1)
                .setFromStation(available.get(Integer.parseInt(id)).getToStation());
        trainData.getTrain().get(Integer.parseInt(id) - 1)
                .setAvailableSeats(trainData.getTrain().get(0).getAvailableSeats() - bookedSeats);
        if (quota.equals("Tatkal"))
            trainData.getTrain().get(Integer.parseInt(id) - 1).setBookedTatkalSeats(bookedSeats);
        else
            trainData.getTrain().get(Integer.parseInt(id) - 1).setBookedReservationSeats(bookedSeats);
        String userID = generateUserID(name);
        if (statement.equals("Waiting List"))
            addWaitingList(userID);
        exit();
    }

    private void addWaitingList(String userID) {
        trainData.getWaitingList().add(userID);
    }

    private String generateUserID(String name) {
        int ch = ' ';
        for (int i = 0; i < name.length(); i++)
            ch += (int) name.charAt(i);
        return ch + "";
    }

    public int paymentTatkal(String seating, int ticketCount) {
        int amount = 0;
        switch (seating) {
            case "AC First Class(1A)":
                amount = ticketCount * tatkal.getAmount().get(0).getFirstAC();
                break;
            case "AC 2Tier(2A)":
                amount = ticketCount * tatkal.getAmount().get(0).getSecondAC();
                break;
            case "AC 3Tier(3A)":
                amount = ticketCount * tatkal.getAmount().get(0).getThirdAC();
                break;
            case "Sleeper(SL)":
                amount = ticketCount * tatkal.getAmount().get(0).getSleeper();
                break;
            case "Second Sitting(2S)":
                amount = ticketCount * tatkal.getAmount().get(0).getSecondSitting();
                break;
        }

        return amount;

    }

    public List<ArrayList<String>> trainDetails() {
        List<ArrayList<String>> trainList = new ArrayList<>();
        for (Train train : trainData.getTrain()) {
            ArrayList<String> trainDetails = new ArrayList<>();
            trainDetails.add(Integer.toString(train.getId()));
            trainDetails.add(train.getTrainName());
            trainDetails.add(train.getTrainNo());
            trainDetails.add(train.getFromStation());
            trainDetails.add(train.getToStation());
            trainDetails.add(train.getTime());
            trainDetails.add(Integer.toString(train.getAvailableSeats()));
            trainDetails.add(Integer.toString(train.getTotalSeats()));
            trainDetails.add(Integer.toString(train.getBookedReservationSeats()));
            trainDetails.add(Integer.toString(train.getBookedTatkalSeats()));
            trainList.add(trainDetails);
        }
        return trainList;
    }

}